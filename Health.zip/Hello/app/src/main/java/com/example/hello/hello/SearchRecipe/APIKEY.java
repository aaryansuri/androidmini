package com.example.hello.hello.SearchRecipe;

public class APIKEY {
    private static final String API_key = "910f364ff37ba47c9ebda2596d501389";
    private static final String API_ID = "27072ba6";

    public static String getAPI_key() {
        return API_key;
    }

    public static String getApiId() {
        return API_ID;
    }
}
