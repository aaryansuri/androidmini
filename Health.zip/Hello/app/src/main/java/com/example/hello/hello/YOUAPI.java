package com.example.hello.hello;

public class YOUAPI {

    private static final String API_key = "AIzaSyBzEfqlsfqm3XRadhe9ZqzVLYwEMwemqGA";

    public static String getAPI_key() {
        return API_key;
    }
}
