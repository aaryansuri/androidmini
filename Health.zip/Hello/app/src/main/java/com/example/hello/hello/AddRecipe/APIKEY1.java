package com.example.hello.hello.AddRecipe;

public class APIKEY1 {
    private static final String API_key = "e09f70a6a83f788647dd8af4df688bbe";
    private static final String API_ID = "5369cc66";

    public static String getAPI_key() {
        return API_key;
    }

    public static String getApiId() {
        return API_ID;
    }
}
